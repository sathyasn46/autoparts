import { Injectable } from '@angular/core';

@Injectable()
export class CompanyDetailsModel{
  
  public companyInfo : any = 
    {
      name : 'Autoparts',
      address : 'No: 1, Ramapuram',
      city: 'Chennai',
      pincode: '600078',
      email: 'customer.care@autoparts.com',
      phone : '044-78945612'
    }
    
  
} 